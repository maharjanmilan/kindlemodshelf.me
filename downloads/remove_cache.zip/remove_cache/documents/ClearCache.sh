#!/bin/sh
# Name: Clear Cache & Thumbnails
# Author: kindlemodshelfguy

/mnt/us/extensions/kterm/bin/kterm -e "bash /mnt/us/clear_cache.sh" -k 1 -o U -s 7