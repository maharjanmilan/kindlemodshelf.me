#!/bin/bash

LD_LIBRARY_PATH=/mnt/us/textadept11 /mnt/us/textadept11/textadept-curses
clear
