#!/bin/bash
echo "Removing /var/local/cmm..."
rm -rf /var/local/cmm

echo "Removing /mnt/us/system/cmm/home..."
rm -rf /mnt/us/system/cmm/home

echo "Cache and thumbnails removed successfully!"
echo "Press enter to exit"
read