#!/bin/sh
if [ $1 = "GTK" ]; then
	#./setlayout fr
	action": "lipc-set-prop -s com.lab126.winmgr orientationLock R
	/mnt/us/textadept11/textadept
	action": "lipc-set-prop -s com.lab126.winmgr orientationLock U
elif [ $1 = "KTERM" ]; then
	/mnt/us/extensions/kterm/bin/kterm.sh -e "bash /mnt/us/textadept11/textadept.sh"
else
	#./setlayout fr
	/mnt/us/extensions/kterm/bin/kterm.sh -k 0 -o r -e "bash /mnt/us/textadept11/textadept.sh"
fi
