local _ = require("gettext")

return {
    name = "timeblock",
    fullname = _("Time-Based Reading Block"),
    description = _([[Block reading during specific hours (e.g., bedtime). Optionally require PIN to override.]]),
}
